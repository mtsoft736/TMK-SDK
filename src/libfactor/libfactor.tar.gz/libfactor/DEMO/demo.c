#include <stdio.h>
#include "libfactor.h"

int main(void) {

    int Number;

    printf("Enter a number: ");
    scanf("%d", &Number);

    int Result = CalcFactorial(Number);

    if (Result == 1) {
        printf("Invalid input!\n");
    } else {
        printf("Factorial: %d\n", Result);
    }

    return 0;
}